<?php
$conn = mysqli_connect("sql212.infinityfree.com", "if0_37824485", "E2fz5UXEtrHqM6t", "if0_37824485_escuela1");

if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}
?>
