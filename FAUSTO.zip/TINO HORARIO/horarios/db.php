<?php
$host = 'sql212.infinityfree.com';
$user = 'if0_37824485';
$password = 'E2fz5UXEtrHqM6t';
$dbname = 'if0_37824485_escuela1';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
